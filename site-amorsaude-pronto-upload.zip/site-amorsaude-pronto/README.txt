PACOTE PRONTO PARA UPLOAD - DASHBOARD MÉDICO

Arquivos principais:
- index.html
- dados-medico.css
- dados-medicos.js
- assets/logo-lag.svg
- assets/lag-ia-mascote.css
- assets/lag-ia-mascote.js

Como subir em plataforma de site comum:
1. Envie a pasta inteira ou o arquivo .zip.
2. Mantenha todos os arquivos na mesma estrutura.
3. O arquivo inicial precisa se chamar index.html.

Observação sobre Shopify:
Shopify não funciona igual hospedagem comum de HTML estático. Para Shopify, normalmente você precisa colocar CSS em assets, JS em assets e inserir o HTML em um tema/section Liquid. Este pacote está pronto para hospedagem estática e também serve como base para converter para Shopify.

Teste local:
Abra index.html no navegador. Se a plataforma permitir, suba o .zip completo.
