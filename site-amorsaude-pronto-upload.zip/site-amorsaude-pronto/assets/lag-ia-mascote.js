/*
  LAG AI - JavaScript do chat flutuante.
  Arquivo criado para manter o pacote completo ao subir em uma plataforma de sites.
*/

(() => {
  const button = document.getElementById("lagWolfButton");
  const chat = document.getElementById("lagWolfChat");
  const closeButton = document.getElementById("lagWolfClose");
  const messages = document.getElementById("lagWolfMessages");
  const form = document.getElementById("lagWolfForm");
  const input = document.getElementById("lagWolfInput");

  if (!button || !chat || !messages) return;

  function openChat() {
    chat.classList.add("active");
    chat.setAttribute("aria-hidden", "false");

    if (input) {
      setTimeout(() => input.focus(), 100);
    }
  }

  function closeChat() {
    chat.classList.remove("active");
    chat.setAttribute("aria-hidden", "true");
  }

  function addMessage(text, type = "bot") {
    const message = document.createElement("div");

    message.className = `lag-wolf-message ${type}`;
    message.innerHTML = text;

    messages.appendChild(message);
    messages.scrollTop = messages.scrollHeight;
  }

  function getDashboardTotals() {
    try {
      if (typeof getFilteredDoctors === "function" && typeof getTotals === "function") {
        return getTotals(getFilteredDoctors());
      }

      if (typeof getTotals === "function") {
        return getTotals();
      }
    } catch (error) {
      console.warn("Não foi possível ler os totais do dashboard.", error);
    }

    return null;
  }

  function getRankingText() {
    const items = [...document.querySelectorAll(".ranking-list .rank-item")].slice(0, 5);

    if (!items.length) {
      return "Ainda não encontrei dados no ranking. Cadastre médicos ou confira os filtros selecionados.";
    }

    return items.map((item, index) => {
      const name = item.querySelector("p")?.textContent?.trim() || `Médico ${index + 1}`;
      const total = item.querySelector("strong")?.textContent?.trim() || "0";

      return `${index + 1}. ${name}: ${total} consultas`;
    }).join("<br>");
  }

  function formatMoney(value) {
    return Number(value || 0).toLocaleString("pt-BR", {
      style: "currency",
      currency: "BRL",
      maximumFractionDigits: 0
    });
  }

  function answer(actionOrText) {
    const text = String(actionOrText || "").toLowerCase();
    const totals = getDashboardTotals();

    if (text.includes("cadastro") || text.includes("adicionar") || text.includes("médico") || text.includes("medico")) {
      const openDoctorButton = document.getElementById("openDoctorPanel");

      if (openDoctorButton) {
        openDoctorButton.click();
        return "Abri o painel de cadastro para você lançar os dados do médico.";
      }

      return "O botão de cadastro não foi encontrado nesta página.";
    }

    if (text.includes("ranking") || text.includes("top") || text.includes("melhor")) {
      return `Aqui está o ranking atual:<br><br>${getRankingText()}`;
    }

    if (text.includes("notícia") || text.includes("noticia") || text.includes("avisos")) {
      const newsButton = document.getElementById("clinicNewsTopButton") || [...document.querySelectorAll(".nav-menu a")].find((link) => {
        const label = link.textContent.trim().toLowerCase();
        return label === "notícias" || label === "noticias";
      });

      if (newsButton) {
        newsButton.click();
        return "Abri o painel de notícias da clínica.";
      }

      return "Não encontrei o botão de notícias no menu.";
    }

    if (text.includes("faltas") || text.includes("ausência") || text.includes("ausencia")) {
      if (!totals) return "Ainda não consegui ler os dados de faltas.";
      return `O período filtrado tem <b>${totals.faltas}</b> faltas, com índice de <b>${totals.indiceFaltas}%</b>.`;
    }

    if (text.includes("arrecada") || text.includes("valor") || text.includes("receita") || text.includes("dinheiro")) {
      if (!totals) return "Ainda não consegui ler a arrecadação.";
      return `A arrecadação do filtro atual é <b>${formatMoney(totals.valor)}</b>, com ticket médio de <b>${formatMoney(totals.ticketMedio)}</b>.`;
    }

    if (!totals || text.includes("resumo") || text.includes("dashboard") || text.includes("indicador") || text.length < 3) {
      if (!totals) {
        return "O dashboard está carregado, mas ainda não consegui calcular os indicadores. Confira se o arquivo dados-medicos.js está na mesma pasta do index.html.";
      }

      return `
        Resumo do filtro atual:<br>
        <b>${totals.medicos}</b> médicos ativos<br>
        <b>${totals.consultas}</b> consultas realizadas<br>
        <b>${formatMoney(totals.valor)}</b> arrecadados<br>
        <b>${totals.taxaOcupacao}%</b> de ocupação
      `;
    }

    return "Posso te ajudar com: <b>resumo</b>, <b>ranking</b>, <b>faltas</b>, <b>arrecadação</b>, <b>notícias</b> ou <b>cadastro</b>.";
  }

  button.addEventListener("click", () => {
    if (chat.classList.contains("active")) {
      closeChat();
    } else {
      openChat();
    }
  });

  if (closeButton) {
    closeButton.addEventListener("click", closeChat);
  }

  document.querySelectorAll("[data-lag-wolf-action]").forEach((actionButton) => {
    actionButton.addEventListener("click", () => {
      const action = actionButton.dataset.lagWolfAction;

      addMessage(actionButton.textContent.trim(), "user");
      addMessage(answer(action), "bot");
    });
  });

  if (form && input) {
    form.addEventListener("submit", (event) => {
      event.preventDefault();

      const userText = input.value.trim();
      if (!userText) return;

      addMessage(userText, "user");
      input.value = "";

      setTimeout(() => {
        addMessage(answer(userText), "bot");
      }, 180);
    });
  }

  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape") closeChat();
  });
})();
